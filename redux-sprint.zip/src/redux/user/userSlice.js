import { createSlice } from "@reduxjs/toolkit";

let initialState = {
  isLoggedIn: false,
  userDetails: null,
  isLoading: true,
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setLoginState: (state, action) => {
      state.isLoggedIn = action.payload;
    },
  },
});


export default userSlice.reducer;
